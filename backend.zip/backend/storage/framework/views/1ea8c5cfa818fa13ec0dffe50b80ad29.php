<?php $__env->startSection('title', 'Manajemen Transaksi Pengembalian - Panel Admin'); ?>
<?php $__env->startSection('header-title', 'Manajemen Transaksi Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-xl bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
    <div class="p-6 border-b border-gray-100">
        <h2 class="text-lg font-bold text-gray-800">Proses Pengembalian Alat</h2>
    </div>

    <div class="p-6">
        <?php if(session('error')): ?>
            <div class="mb-4 bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-sm">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.pengembalian.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Pilih Transaksi Peminjaman</label>
                <select name="peminjaman_id" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <option value="">-- Pilih Transaksi Peminjaman --</option>
                    <?php $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pinjam->id); ?>">
                            <?php echo e($pinjam->user->name ?? 'User'); ?> - 
                            [Alat: <?php $__currentLoopData = $pinjam->detailPinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($d->alat->nama_alat ?? ''); ?> (<?php echo e($d->jumlah); ?>pcs) <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Tanggal Dikembalikan</label>
                <input type="date" name="tgl_kembali" value="<?php echo e(date('Y-m-d')); ?>" required 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Kondisi Alat Saat Kembali</label>
                <input type="text" name="kondisi_kembali" value="Lengkap dan Berfungsi Baik" required 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Denda Total (Rp) - Manual</label>
                <input type="number" name="denda_manual" min="0" placeholder="Kosongkan jika ingin dihitung otomatis"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
            </div>

            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Tarif Denda Harian (Rp / Hari)</label>
                <input type="number" name="tarif_harian" value="1000" min="0" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
            </div>

            <div class="flex items-center space-x-2">
                <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-lg text-sm font-semibold transition">Simpan Pengembalian</button>
                <a href="<?php echo e(route('admin.pengembalian.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-lg text-sm font-semibold transition">Batal</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/pengembalian/create.blade.php ENDPATH**/ ?>